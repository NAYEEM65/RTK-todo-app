import { useState } from 'react';
import cancelImage from '../assets/images/cancel.png';
import {
    useDeleteTodoMutation,
    useEditColorChangeMutation,
    useEditStatusMutation,
    useEditTodoMutation,
} from '../features/api/apiSlice';

export default function Todo({ todo }) {
    const { text, id, completed, color } = todo;
    const [editTodo] = useEditTodoMutation();
    const [editStatus] = useEditStatusMutation();
    const [editColorChange] = useEditColorChangeMutation();
    const [isEditing, setIsEditing] = useState(false);
    const [todoText, setTodoText] = useState(text);

    const handleStatusChange = () => {
        editStatus({
            id,
            data: {
                completed: !completed,
            },
        });
    };

    const handleColorChange = (color) => {
        editColorChange({
            id,
            data: {
                color: color,
            },
        });
    };

    const updateHandler = (e) => {
        e.preventDefault();
        editTodo({
            id,
            data: {
                text: todoText,
            },
        });
        setIsEditing(false);
    };

    const [deleteTodo] = useDeleteTodoMutation();
    const handleDelete = () => {
        if (id) deleteTodo(id);
    };
    return (
        <>
            <div className="flex justify-start items-center p-2 hover:bg-gray-100 hover:transition-all space-x-4 border-b border-gray-400/20 last:border-0">
                <div
                    className={`relative rounded-full bg-white border-2 border-gray-400 w-5 h-5 flex flex-shrink-0 justify-center items-center mr-2 ${
                        completed && 'border-green-500 focus-within:border-green-500'
                    }`}
                >
                    <input
                        type="checkbox"
                        checked={completed}
                        onChange={handleStatusChange}
                        className="opacity-0 absolute rounded-full"
                    />
                    {completed && (
                        <svg
                            className="fill-current w-3 h-3 text-green-500 pointer-events-none"
                            viewBox="0 0 20 20"
                        >
                            <path d="M0 11l2-2 5 5L18 3l2 2L7 18z" />
                        </svg>
                    )}
                </div>
                {isEditing ? (
                    <form
                        method="PATCH"
                        className="flex items-center bg-gray-100 px-4 py-4 rounded-md w-4/5"
                        onSubmit={updateHandler}
                    >
                        <input
                            type="text"
                            placeholder="Type your todo"
                            className="w-full  px-4 py-2 border-none outline-none bg-gray-200 text-lime-600 text-sm"
                            value={todoText}
                            onChange={(e) => setTodoText(e.target.value)}
                        />
                        <button
                            type="submit"
                            className={`appearance-none w-8 h-8  bg-no-repeat bg-contain`}
                        >
                            <svg
                                width="24"
                                height="24"
                                xmlns="http://www.w3.org/2000/svg"
                                fillRule="evenodd"
                                clipRule="evenodd"
                                stroke="currentColor"
                                className="fill-green-600 stroke-green-600 rounded"
                            >
                                <path d="M24 6.278l-11.16 12.722-6.84-6 1.319-1.49 5.341 4.686 9.865-11.196 1.475 1.278zm-22.681 5.232l6.835 6.01-1.314 1.48-6.84-6 1.319-1.49zm9.278.218l5.921-6.728 1.482 1.285-5.921 6.756-1.482-1.313z" />
                            </svg>
                        </button>
                    </form>
                ) : (
                    <div className={`select-none flex-1 ${completed && 'line-through'}`}>
                        {todoText}
                    </div>
                )}

                <div
                    className={`flex-shrink-0 h-4 w-4 ml-auto cursor-pointer 
                }`}
                    onClick={() => setIsEditing(true)}
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        className="fill-green-600"
                    >
                        <path d="M14.078 4.232l-12.64 12.639-1.438 7.129 7.127-1.438 12.641-12.64-5.69-5.69zm-10.369 14.893l-.85-.85 11.141-11.125.849.849-11.14 11.126zm2.008 2.008l-.85-.85 11.141-11.125.85.85-11.141 11.125zm18.283-15.444l-2.816 2.818-5.691-5.691 2.816-2.816 5.691 5.689z" />
                    </svg>
                </div>

                <div
                    className={`flex-shrink-0 h-4 w-4 rounded-full border-2 ml-auto cursor-pointer hover:bg-green-500 border-green-500 ${
                        color === 'green' && 'bg-green-500'
                    }`}
                    onClick={() => handleColorChange('green')}
                ></div>

                <div
                    className={`flex-shrink-0 h-4 w-4 rounded-full border-2 ml-auto cursor-pointer hover:bg-yellow-500 border-yellow-500 ${
                        color === 'yellow' && 'bg-yellow-500'
                    }`}
                    onClick={() => handleColorChange('yellow')}
                ></div>

                <div
                    className={`flex-shrink-0 h-4 w-4 rounded-full border-2 ml-auto cursor-pointer hover:bg-red-500 border-red-500 ${
                        color === 'red' && 'bg-red-500'
                    }`}
                    onClick={() => handleColorChange('red')}
                ></div>

                <img
                    onClick={handleDelete}
                    src={cancelImage}
                    className="flex-shrink-0 w-4 h-4 ml-2 cursor-pointer"
                    alt="Cancel"
                />
            </div>
        </>
    );
}
