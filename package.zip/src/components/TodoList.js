import { useGetTodosQuery } from '../features/api/apiSlice';
import Todo from './Todo';

export default function TodoList() {
    const { data: todos, isLoading, isError } = useGetTodosQuery();

    let content = null;
    if (isLoading) {
        content = <div>Loading...</div>;
    }
    if (!isLoading && isError) {
        content = <div className="text-danger">There was an Error</div>;
    }
    if (!isLoading && !isError && todos?.length > 0) {
        content = todos.map((todo) => <Todo key={todo.id} todo={todo} />);
    }

    return content;
}
