import Header from './components/Header';
import Navbar from './components/Navbar';
import TodoList from './components/TodoList';

function App() {
    return (
        <>
            <div className="grid gap-6 py-20 place-items-center bg-blue-100 h-auto px-6 font-sans">
                <Navbar />

                <div className="w-full max-w-3xl shadow-lg rounded-lg p-6 bg-white">
                    <Header />

                    <hr className="mt-4" />

                    <TodoList />

                    <hr className="mt-4" />

                    {/* <Footer completed={false} /> */}
                </div>
                {/* <div className="w-full max-w-3xl shadow-lg rounded-lg p-6 bg-white">
                    <h1 className="text-center text-emerald-500 text-lg border-b-2 border-emerald-500 w-40">
                        Completed Task
                    </h1>
                    <hr className="mt-4" />
                    {<CompletedTodo />}
                    <hr className="mt-4" />

                    <Footer completed={true} />
                </div> */}
            </div>
        </>
    );
}

export default App;
